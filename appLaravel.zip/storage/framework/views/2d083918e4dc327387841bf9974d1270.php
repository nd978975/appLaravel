[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\code\code\appLaravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>